import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

try:
    from pynput import mouse, keyboard
except ImportError:
    mouse = None
    keyboard = None


BG = "#111111"
PANEL = "#171717"
PANEL_2 = "#1d1d1d"
BORDER = "#303030"
TEXT = "#eeeeee"
MUTED = "#8f8f8f"
ACCENT = "#d7ad45"
GREEN = "#62d18a"
RED = "#e26d6d"


class AutoClicker:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Clicker")
        self.root.geometry("430x360")
        self.root.minsize(430, 360)
        self.root.configure(bg=BG)
        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self.mouse_controller = mouse.Controller() if mouse else None
        self.hotkey_listener = None
        self.running = False
        self.stop_event = threading.Event()
        self.worker = None
        self.click_count = 0

        self.cps = tk.IntVar(value=10)
        self.button = tk.StringVar(value="left")
        self.hotkey = tk.StringVar(value="F6")
        self.limit_enabled = tk.BooleanVar(value=False)
        self.limit = tk.IntVar(value=100)
        self.status = tk.StringVar(value="Ready")
        self.count_text = tk.StringVar(value="0 clicks")

        self.setup_style()
        self.build_ui()
        self.start_hotkey_listener()

    def setup_style(self):
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("Card.TFrame", background=PANEL)
        style.configure("TCheckbutton", background=PANEL, foreground=TEXT, font=("Segoe UI", 9))
        style.map("TCheckbutton", background=[("active", PANEL)])
        style.configure("TButton", background=PANEL_2, foreground=TEXT, borderwidth=0, relief="flat", padding=(10, 7), font=("Segoe UI", 9))
        style.map("TButton", background=[("active", "#272727")])

    def card(self, parent):
        outer = tk.Frame(parent, bg=BORDER)
        inner = tk.Frame(outer, bg=PANEL)
        inner.pack(fill="both", expand=True, padx=1, pady=1)
        return outer, inner

    def label(self, parent, text, size=10, color=TEXT, weight="normal"):
        return tk.Label(parent, text=text, bg=PANEL, fg=color, font=("Segoe UI", size, weight))

    def build_ui(self):
        top = tk.Frame(self.root, bg=BG)
        top.pack(fill="x", padx=18, pady=(14, 8))

        title = tk.Label(top, text="Clicker", bg=BG, fg=TEXT, font=("Segoe UI", 15, "bold"))
        title.pack(side="left")
        tk.Label(top, text="simple auto clicker", bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(side="left", padx=10, pady=(4, 0))

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=18, pady=4)

        speed_outer, speed = self.card(body)
        speed_outer.pack(fill="x", pady=(0, 10))
        self.label(speed, "CLICK SPEED", 9, MUTED, "bold").pack(anchor="w", padx=14, pady=(12, 7))

        speed_row = tk.Frame(speed, bg=PANEL)
        speed_row.pack(fill="x", padx=14)
        self.label(speed_row, "Clicks per second", 10).pack(side="left")
        self.cps_spin = tk.Spinbox(
            speed_row, from_=1, to=50, textvariable=self.cps, width=6,
            bg=PANEL_2, fg=TEXT, insertbackground=TEXT, buttonbackground=PANEL_2,
            relief="flat", highlightthickness=1, highlightbackground=BORDER,
            highlightcolor=ACCENT, font=("Segoe UI", 10), justify="center"
        )
        self.cps_spin.pack(side="right", pady=2)

        hint = tk.Label(speed, text="1–50 clicks/sec", bg=PANEL, fg=MUTED, font=("Segoe UI", 8))
        hint.pack(anchor="w", padx=14, pady=(4, 12))

        button_outer, button_panel = self.card(body)
        button_outer.pack(fill="x", pady=(0, 10))
        self.label(button_panel, "MOUSE BUTTON", 9, MUTED, "bold").pack(anchor="w", padx=14, pady=(12, 7))

        btns = tk.Frame(button_panel, bg=PANEL)
        btns.pack(fill="x", padx=14, pady=(0, 12))
        self.button_widgets = {}
        for value, text in (("left", "Left"), ("middle", "Middle"), ("right", "Right")):
            b = tk.Button(
                btns, text=text, command=lambda v=value: self.select_button(v),
                bg=PANEL_2, fg=TEXT, activebackground="#292929", activeforeground=TEXT,
                relief="flat", bd=0, font=("Segoe UI", 9), padx=13, pady=6, cursor="hand2"
            )
            b.pack(side="left", padx=(0, 6))
            self.button_widgets[value] = b
        self.refresh_button_styles()

        limit_outer, limit_panel = self.card(body)
        limit_outer.pack(fill="x", pady=(0, 10))
        row = tk.Frame(limit_panel, bg=PANEL)
        row.pack(fill="x", padx=14, pady=(12, 12))
        ttk.Checkbutton(row, text="Stop after", variable=self.limit_enabled).pack(side="left")
        self.limit_spin = tk.Spinbox(
            row, from_=1, to=999999, textvariable=self.limit, width=8,
            bg=PANEL_2, fg=TEXT, insertbackground=TEXT, buttonbackground=PANEL_2,
            relief="flat", highlightthickness=1, highlightbackground=BORDER,
            highlightcolor=ACCENT, font=("Segoe UI", 9), justify="center"
        )
        self.limit_spin.pack(side="left", padx=8)
        tk.Label(row, text="clicks", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(side="left")

        bottom = tk.Frame(self.root, bg=BG)
        bottom.pack(fill="x", padx=18, pady=(0, 16))

        status_row = tk.Frame(bottom, bg=BG)
        status_row.pack(fill="x", pady=(0, 8))
        self.status_dot = tk.Label(status_row, text="●", bg=BG, fg=GREEN, font=("Segoe UI", 9))
        self.status_dot.pack(side="left")
        tk.Label(status_row, textvariable=self.status, bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(side="left", padx=6)
        tk.Label(status_row, textvariable=self.count_text, bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(side="right")

        controls = tk.Frame(bottom, bg=BG)
        controls.pack(fill="x")
        self.start_btn = tk.Button(
            controls, text="START  •  F6", command=self.toggle,
            bg=ACCENT, fg="#111111", activebackground="#e2b95d", activeforeground="#111111",
            relief="flat", bd=0, font=("Segoe UI", 10, "bold"), padx=14, pady=9, cursor="hand2"
        )
        self.start_btn.pack(side="left", fill="x", expand=True)

        reset_btn = tk.Button(
            controls, text="Reset", command=self.reset_count,
            bg=PANEL_2, fg=TEXT, activebackground="#292929", activeforeground=TEXT,
            relief="flat", bd=0, font=("Segoe UI", 9), padx=14, pady=9, cursor="hand2"
        )
        reset_btn.pack(side="left", padx=(8, 0))

        tk.Label(
            self.root, text="F6 starts/stops the clicker", bg=BG, fg=MUTED,
            font=("Segoe UI", 8)
        ).pack(pady=(0, 10))

    def select_button(self, value):
        if self.running:
            return
        self.button.set(value)
        self.refresh_button_styles()

    def refresh_button_styles(self):
        for value, widget in self.button_widgets.items():
            if self.button.get() == value:
                widget.configure(bg=ACCENT, fg="#111111", activebackground="#e2b95d", activeforeground="#111111")
            else:
                widget.configure(bg=PANEL_2, fg=TEXT, activebackground="#292929", activeforeground=TEXT)

    def start_hotkey_listener(self):
        if keyboard is None:
            return
        try:
            self.hotkey_listener = keyboard.GlobalHotKeys({"<f6>": self.toggle_from_listener})
            self.hotkey_listener.start()
        except Exception:
            self.hotkey_listener = None

    def toggle_from_listener(self):
        self.root.after(0, self.toggle)

    def toggle(self):
        if self.running:
            self.stop()
        else:
            self.start()

    def start(self):
        try:
            cps = max(1, min(50, int(self.cps.get())))
        except (ValueError, tk.TclError):
            messagebox.showerror("Invalid speed", "Enter a clicks-per-second value from 1 to 50.")
            return

        if self.limit_enabled.get():
            try:
                limit = max(1, int(self.limit.get()))
            except (ValueError, tk.TclError):
                messagebox.showerror("Invalid limit", "Enter a valid click limit.")
                return
        else:
            limit = None

        if self.mouse_controller is None:
            messagebox.showerror("Missing dependency", "Install the packages from requirements.txt first.")
            return

        self.running = True
        self.stop_event.clear()
        self.status.set("Running")
        self.status_dot.configure(fg=GREEN)
        self.start_btn.configure(text="STOP  •  F6", bg=RED, activebackground="#ef8585")
        self.cps_spin.configure(state="disabled")
        self.limit_spin.configure(state="disabled")
        for b in self.button_widgets.values():
            b.configure(state="disabled")
        self.worker = threading.Thread(target=self.click_loop, args=(cps, limit), daemon=True)
        self.worker.start()

    def stop(self):
        self.running = False
        self.stop_event.set()
        self.status.set("Stopped")
        self.status_dot.configure(fg=MUTED)
        self.start_btn.configure(text="START  •  F6", bg=ACCENT, activebackground="#e2b95d")
        self.cps_spin.configure(state="normal")
        self.limit_spin.configure(state="normal")
        for b in self.button_widgets.values():
            b.configure(state="normal")
        self.refresh_button_styles()

    def click_loop(self, cps, limit):
        interval = 1.0 / cps
        button = {
            "left": mouse.Button.left,
            "middle": mouse.Button.middle,
            "right": mouse.Button.right,
        }[self.button.get()]

        while not self.stop_event.is_set():
            started = time.perf_counter()
            self.mouse_controller.click(button)
            self.click_count += 1
            self.root.after(0, self.update_count)

            if limit is not None and self.click_count >= limit:
                self.root.after(0, self.stop)
                break

            remaining = interval - (time.perf_counter() - started)
            if remaining > 0:
                self.stop_event.wait(remaining)

    def update_count(self):
        label = "click" if self.click_count == 1 else "clicks"
        self.count_text.set(f"{self.click_count:,} {label}")

    def reset_count(self):
        self.click_count = 0
        self.update_count()
        self.status.set("Ready" if not self.running else "Running")

    def close(self):
        self.stop_event.set()
        self.running = False
        try:
            if self.hotkey_listener:
                self.hotkey_listener.stop()
        except Exception:
            pass
        self.root.destroy()


def main():
    root = tk.Tk()
    app = AutoClicker(root)
    root.mainloop()


if __name__ == "__main__":
    main()
