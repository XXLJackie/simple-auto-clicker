# Clicker

A small desktop auto clicker inspired by compact utility apps. It keeps the basics only: click speed, mouse button, optional click limit, start/stop, reset, and a global F6 hotkey.

## Run

Python 3.10+ is recommended.

```bash
pip install -r requirements.txt
python main.py
```

Press **F6** to start or stop clicking.

## Notes

This is a simple example project. It uses `pynput` for mouse control and the global F6 hotkey.
